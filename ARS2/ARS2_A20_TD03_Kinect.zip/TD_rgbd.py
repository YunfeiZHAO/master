#!/usr/bin/env python
import numpy as np
import cv2
import pptk # pip install pptk # !! Ubuntu users, pptk has a bug with libz.so.1, see how to do a new symlink in https://github.com/heremaps/pptk/issues/3
#from write_and_read_sync_imgs import open_shot
#Note: Be careful, "depths" given by Kinect are not actually "depths" but disparities. In common language, these terms are often considered the same.

#%%
def open_shot(n, fromdir='./shots'):
    # open a shot according to its number
    depth = cv2.imread('{}/{:02d}_depth.png'.format(fromdir, n), cv2.IMREAD_ANYDEPTH)
    depth_pretty = cv2.imread('{}/{:02d}_depth_pretty.png'.format(fromdir, n))
    bgr = cv2.imread('{}/{:02d}_rgb.png'.format(fromdir, n))
    return depth, depth_pretty, bgr

#%%
def raw_depth_to_meters(raw_disp):
    # get distances in meter from depth given by Kinect
    # Kinect computes the depth, but outputs a value coded a specific way in [[0;2047]] on 11 bits
    m_depth = np.zeros_like(raw_disp, dtype=np.float)
    # raw_disp must be transformed, some explanations in https://wiki.ros.org/kinect_calibration/technical
    
    # TODO
    
    return m_depth

#%%
def xyz_from_depth_meters(m_depth):
    # computes points 3D coordinates from depth
    
    # TODO
    
    return xyz

#%%
def color_of_xyz(xyz, rgb_img):
    # associate colors to depth / 3D points
    
    # TODO
    
    return rgb_colors


#%%
def main(shot):
    depth, depth_pretty, bgr = open_shot(shot) # open RGB and D data of the shot
    cv2.imshow('Depth', depth_pretty) # display depth
    cv2.imshow('RGB', bgr) # display RGB

    # depth map in meters
    #m_depth = raw_depth_to_meters(depth)

    # show in 3D point cloud
    #xyz = xyz_from_depth_meters(m_depth)
    # no-colored version
    #v = pptk.viewer(xyz) # show 3D point cloud
    #v.set(point_size=0.001)

    #add color information
    #rgb_colors = color_of_xyz(xyz, bgr)
    #v.attributes(rgb_colors / 255.)


    while 1:
        if cv2.waitKey(10) == 27:
            cv2.destroyAllWindows()
            #v.close()
            break

#%%
if __name__ == "__main__":
    cv2.namedWindow('Depth')
    cv2.namedWindow('RGB')
    print('Press ESC in window to stop')

    shot = 6 # shot number to open
    main(shot)
